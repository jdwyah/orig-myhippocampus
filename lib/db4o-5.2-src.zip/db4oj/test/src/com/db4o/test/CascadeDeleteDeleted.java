/* Copyright (C) 2004 - 2005  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.test;

import com.db4o.*;
import com.db4o.ext.*;
import com.db4o.query.*;


public class CascadeDeleteDeleted {
    
    public String name;
    
    public Object untypedMember;
    public CddMember typedMember;
    
    public CascadeDeleteDeleted(){
    }
    
    public CascadeDeleteDeleted(String name){
        this.name = name;
    }
    
    public void configure(){
        Db4o.configure().objectClass(this).cascadeOnDelete(true);
    }
    
    public void store(){
        
        Test.deleteAllInstances(CddMember.class);        
        
        membersFirst("membersFirst commit");
        membersFirst("membersFirst");
        
        twoRef("twoRef");
        twoRef("twoRef commit");
        twoRef("twoRef delete");
        twoRef("twoRef delete commit");
    }

    private void membersFirst(String name){
        CascadeDeleteDeleted cdd = new CascadeDeleteDeleted(name);
        cdd.untypedMember = new CddMember();
        cdd.typedMember = new CddMember();
        Test.store(cdd);
    }

    private void twoRef(String name){
        CascadeDeleteDeleted cdd = new CascadeDeleteDeleted(name);
        cdd.untypedMember = new CddMember();
        cdd.typedMember = new CddMember();
        CascadeDeleteDeleted cdd2 = new CascadeDeleteDeleted(name);
        cdd2.untypedMember = cdd.untypedMember;
        cdd2.typedMember = cdd.typedMember;
        Test.store(cdd);
        Test.store(cdd2);
        
    }
    
    
    public void test(){
        tMembersFirst("membersFirst commit");
        tMembersFirst("membersFirst");
        tTwoRef("twoRef");
        tTwoRef("twoRef commit");
        tTwoRef("twoRef delete");
        tTwoRef("twoRef delete commit");
        Test.ensureOccurrences(CddMember.class, 0);
    }
    
    private void tMembersFirst(String name){
        boolean commit = name.indexOf("commit") > 1;
        ExtObjectContainer oc = Test.objectContainer();
        Query q = oc.query();
        q.constrain(this.getClass());
        q.descend("name").constrain(name);
        ObjectSet objectSet = q.execute();
        CascadeDeleteDeleted cdd = (CascadeDeleteDeleted)objectSet.next();
        oc.delete(cdd.untypedMember);
        oc.delete(cdd.typedMember);
        if(commit){
            oc.commit();
        }
        oc.delete(cdd);
        if(!commit){
            oc.commit();
        }
    }
    
    private void tTwoRef(String name){
        boolean commit = name.indexOf("commit") > 1;
        boolean delete = name.indexOf("delete") > 1;
        ExtObjectContainer oc = Test.objectContainer();
        Query q = oc.query();
        q.constrain(this.getClass());
        q.descend("name").constrain(name);
        ObjectSet objectSet = q.execute();
        CascadeDeleteDeleted cdd = (CascadeDeleteDeleted)objectSet.next();
        CascadeDeleteDeleted cdd2 = (CascadeDeleteDeleted)objectSet.next();
        if(delete){
            oc.delete(cdd.untypedMember);
            oc.delete(cdd.typedMember);
        }
        oc.delete(cdd);
        if(commit){
            oc.commit();
        }
        oc.delete(cdd2);
        if(!commit){
            oc.commit();
        }
    }

    
    public static class CddMember{
        public String name;
        
    }
    
}
