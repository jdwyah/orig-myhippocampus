/* Copyright (C) 2004 - 2005  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.test;

import java.io.*;

import com.db4o.*;
import com.db4o.io.*;
import com.db4o.io.crypt.*;
import com.db4o.query.*;

public class XTEAEncryption {
	private static final int NUMSTORED = 100;
	public int id;
	public String name;
	public XTEAEncryption parent;
	
	public XTEAEncryption() {
		this(0,null,null);
	}
	
	public XTEAEncryption(int id, String name, XTEAEncryption parent) {
		this.id = id;
		this.name = name;
		this.parent = parent;
	}

	public void test() {
		Db4o.configure().blockSize(1);
		Db4o.configure().io(new XTeaEncryptionFileAdapter("db4o"));

		new File("encrypted.yap").delete();
		ObjectContainer db=Db4o.openFile("encrypted.yap");		
		XTEAEncryption last=null;
		for(int i=0;i<NUMSTORED;i++) {
			XTEAEncryption current=new XTEAEncryption(i,"X"+i,last);
			db.set(current);
			last=current;
		}
		db.close();
		
		db=Db4o.openFile("encrypted.yap");		
		Query query=db.query();
		query.constrain(getClass());
		query.descend("id").constrain(new Integer(50));
		Test.ensure(query.execute().size()==1);
		db.close();
		
		Db4o.configure().io(new RandomAccessFileAdapter());
	}
}
